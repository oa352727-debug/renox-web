// RENOX PROJECT — Telegram server status bot
// Configure BOT_TOKEN, BOT_OWNER_ID and BOT_GROUP_ID in Termux environment.
// This bot is intentionally standalone and uses Node.js built-in fetch only.
const os = require("os");
const fs = require("fs");
const path = require("path");
const http = require("http");

const TOKEN = process.env.BOT_TOKEN;
const OWNER_ID = String(process.env.BOT_OWNER_ID || "");
const GROUP_ID = String(process.env.BOT_GROUP_ID || "");
const PORT = Number(process.env.PORT || process.env.SERVER_PORT || 2429);
const PROJECT = process.env.RENOX_DIR || __dirname;
const API = `https://api.telegram.org/bot${TOKEN}`;
let offset = 0;
let lastCpu = os.cpus().map(c => ({...c.times}));
let lastCpuAt = Date.now();

if (!TOKEN) {
  console.error("BOT_TOKEN belum diatur. Set token bot Telegram terlebih dahulu.");
  process.exit(1);
}
if (!OWNER_ID) {
  console.error("BOT_OWNER_ID belum diatur. Bot dihentikan agar akses private tidak terbuka.");
  process.exit(1);
}

async function telegram(method, body={}) {
  const r = await fetch(`${API}/${method}`, {
    method: "POST", headers: {"Content-Type":"application/json"},
    body: JSON.stringify(body), signal: AbortSignal.timeout(20000)
  });
  const data = await r.json();
  if (!data.ok) throw new Error(data.description || `Telegram API ${r.status}`);
  return data.result;
}
function cpuUsage() {
  const cpus=os.cpus(), now=Date.now();
  let idle=0,total=0;
  cpus.forEach((c,i)=>{
    const t=c.times, old=lastCpu[i]||t;
    const dIdle=t.idle-old.idle, dTotal=Object.keys(t).reduce((s,k)=>s+(t[k]-old[k]),0);
    idle+=dIdle; total+=dTotal;
  });
  lastCpu=cpus.map(c=>({...c.times}));lastCpuAt=now;
  return total>0?Math.max(0,Math.min(100,(1-idle/total)*100)):0;
}
async function stats() {
  const mem=os.totalmem(),free=os.freemem(),used=mem-free;
  const cpus=os.cpus(),load=os.loadavg();
  let up=0;
  try { const r=await fetch(`http://127.0.0.1:${PORT}/api/health`,{signal:AbortSignal.timeout(2500)}); const h=await r.json(); up=Number(h.uptime||0); } catch {}
  const fmt=s=>{s=Math.floor(s);const d=Math.floor(s/86400);s%=86400;const h=Math.floor(s/3600);s%=3600;const m=Math.floor(s/60);s%=60;return [d?d+"h":null,h+"j",m+"m",s+"d"].filter(Boolean).join(" ")};
  const projectDb=path.join(PROJECT,"data","renox-db.json");
  let users="—",messages="—";
  try{const db=JSON.parse(fs.readFileSync(projectDb,"utf8"));users=Object.keys(db.accounts||{}).length;messages=(db.messages||[]).length;}catch{}
  return `📊 *RENOX PROJECT SERVER STATS*\n\n🟢 Status: ONLINE\n⏱ Runtime server: ${up?fmt(up):"tidak terhubung"}\n🖥 CPU: ${cpuUsage().toFixed(1)}% · ${cpus.length} core\n📈 Load average: ${load.map(x=>x.toFixed(2)).join(" / ")}\n🧠 RAM: ${(used/1024**3).toFixed(2)} GB / ${(mem/1024**3).toFixed(2)} GB (${(used/mem*100).toFixed(1)}%)\n🟩 RAM bebas: ${(free/1024**3).toFixed(2)} GB\n👥 Akun lokal: ${users}\n💬 Pesan Global Chat tersimpan: ${messages}\n📦 Project: RENOX PROJECT`;
}
async function send(chatId,text,extra={}) {
  return telegram("sendMessage",{chat_id:chatId,text,parse_mode:"Markdown",...extra});
}
async function poll() {
  try {
    const updates=await telegram("getUpdates",{offset,timeout:25,allowed_updates:["message"]});
    for(const u of updates) {
      offset=u.update_id+1;
      const m=u.message;if(!m?.chat)continue;
      const chatId=String(m.chat.id),type=m.chat.type,text=String(m.text||"").trim();
      if(type==="private") {
        if(String(m.from?.id)!==OWNER_ID) {
          await send(chatId,"⛔ Bot pribadi hanya dapat digunakan oleh developer.");
          continue;
        }
        if(/^\/(start|help)(@\w+)?$/i.test(text)) {
          await send(chatId,"👋 *RENOX DEVELOPER BOT*\n\n/stats — statistik server\n/status — status server\n/help — bantuan");
        } else if(/^\/(stats|status)(@\w+)?$/i.test(text)) {
          await send(chatId,await stats());
        } else if(text.startsWith("/")) {
          await send(chatId,"Perintah tidak dikenal. Gunakan /stats atau /help.");
        }
      } else if(type==="group"||type==="supergroup") {
        if(!GROUP_ID || chatId!==GROUP_ID)continue;
        if(/^\/(start|status)(@\w+)?$/i.test(text)) {
          await send(chatId,"🟢 *Server Renox Online Nih bouz*\nGunakan /stats untuk melihat statistik server.");
        } else if(/^\/stats(@\w+)?$/i.test(text)) {
          await send(chatId,await stats());
        }
      }
    }
  } catch(e) {
    console.error("Telegram polling:",e.message);
    await new Promise(r=>setTimeout(r,3500));
  }
}
async function boot() {
  try {
    const me=await telegram("getMe",{});
    console.log(`Renox bot connected: @${me.username}`);
    if(GROUP_ID) {
      try { await send(GROUP_ID,"🟢 *Server Renox Online Nih bouz*\nRENOX PROJECT telah aktif. Ketik /stats untuk statistik server."); }
      catch(e){console.error("Gagal mengirim pengumuman grup:",e.message);}
    }
    while(true)await poll();
  } catch(e) {
    console.error("Bot gagal mulai:",e.message);
    process.exit(1);
  }
}
boot();
